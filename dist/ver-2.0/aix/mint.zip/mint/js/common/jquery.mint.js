/*!
 * 제이쿼리를 확장한 공통 스크립트 파일
 *
 */
(function( $ ) {
	/**
	 * bootstrap-inspinia Collapse Event Extended
	 */
	$.fn.panelCollapseEvent = function() {
		$(this).off("click");
		$(this).on("click", function() {
	        var ibox = $(this).closest('div.ibox');
	        var button = $(this).find('i');
	        var content = ibox.find('div.ibox-content');
	        content.slideToggle(200);
	        button.toggleClass('fa-chevron-up').toggleClass('fa-chevron-down');
	        ibox.toggleClass('').toggleClass('border-bottom');
	        setTimeout(function () {
	            ibox.resize();
	            ibox.find('[id^=map-]').resize();
	        }, 50);
		});
	};

	/**
	 * bootstrap-inspinia FullScreen Event Extended
	 */
	$.fn.panelFullScreenEvent = function() {
		$(this).off("click");
		$(this).on("click", function() {

	        var ibox = $(this).closest('div.ibox');
	        var button = $(this).find('i');
	        $('body').toggleClass('fullscreen-ibox-mode');
	        button.toggleClass('fa-expand').toggleClass('fa-compress');
	        ibox.toggleClass('fullscreen');
	        setTimeout(function () {
	            $(window).trigger('resize');
	        }, 100);

	        var mintPanel = $(this).closest('div.mint-panel');
	        var mintPannelButton = $(this).find('i');
	        $('body').toggleClass('fullscreen-mint-panel-mode');
	        mintPannelButton.toggleClass('fa-expand').toggleClass('fa-compress');
	        mintPanel.toggleClass('fullscreen');
	        setTimeout(function () {
	            $(window).trigger('resize');
	        }, 100);


		});
	};


	$.expr[':'].containsIgnoreCase = function (el, idx, meta) {
		//console.log(jQuery(el).text().toUpperCase() + ', ' + meta[3] + ', ' + jQuery(el).text().toUpperCase().indexOf(meta[3].toUpperCase()));
	    return jQuery(el).text().toUpperCase().indexOf(meta[3].toUpperCase()) >= 0;
	};


}( jQuery ));